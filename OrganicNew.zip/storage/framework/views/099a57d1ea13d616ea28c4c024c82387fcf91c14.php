<?php $__env->startSection('title', 'Organic Food : Order List'); ?>

<?php $__env->startSection('content'); ?>
    <section class="product_section">
        <div class="container">
            <div class="order_listbox">
                <div class="carousal_head">
                    <span class="filter_head_txt slider_headtxt">My Orders List</span>
                </div>
                <div class="order_list_container">
                    <div class="order_row">
                        <div class="order_header">
                            <div class="order_no">OrganicDolchi012045</div>
                            <div class="order_amt pull-right"><i class="mdi mdi-currency-inr"></i> 300.00</div>
                        </div>
                        <div class="order_details_box">
                            <div class="col-md-8 col-sm-12">
                                <div class="productdetails_order_row">
                                    <div class="order_product_imgbox">
                                        <img src="images/product_09.jpg" alt="Organic product">
                                    </div>
                                    <div class="product_name">
                                        <a class="product_details_link" href="product_details.php"> Fortune Plus Soya Oil Pouch 1 LT</a>
                                    </div>
                                    <div class="option_availability">
                                        <div class="option_txt">Product Type </div>
                                        <div class="product_right_txt">
                                            Whole Grains
                                        </div>
                                    </div>
                                    <div class="option_availability">
                                        <div class="option_txt">Container Type </div>
                                        <div class="product_right_txt">
                                            Bottle
                                        </div>
                                    </div>
                                    <div class="option_availability">
                                        <div class="option_txt">Sales Package </div>
                                        <div class="product_right_txt">
                                            Oil Bottle (60 ml)
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-12">
                                <div class="track_del_address">
                                    Gohalpur New Basti No.1 Amkhera Road
                                </div>
                                <div class="track_status">
                                    <p><b>Item packed on 12-Apr-2018</b></p>
                                    <span class="del_status">Your item has been packed</span>
                                </div>
                            </div>
                        </div>
                        <div class="order_track">
                            <ol class="progtrckr" data-progtrckr-steps="5">
                                <li class="progtrckr-done">Ordered</li>
                                <li class="progtrckr-done">Packed</li>
                                <li class="progtrckr-todo">Shipped</li>
                                <li class="progtrckr-todo">Delivered</li>
                            </ol>
                        </div>
                    </div>
                    <div class="order_row">
                        <div class="order_header">
                            <div class="order_no">OrganicDolchi012045</div>
                            <div class="order_amt pull-right"><i class="mdi mdi-currency-inr"></i> 300.00</div>
                        </div>
                        <div class="order_details_box">
                            <div class="col-md-8 col-sm-12">
                                <div class="productdetails_order_row">
                                    <div class="order_product_imgbox">
                                        <img src="images/product_02.jpg" alt="Organic product">
                                    </div>
                                    <div class="product_name">
                                        <a class="product_details_link" href="product_details.php">Fortune Plus Soya Oil Pouch 1 LT</a>
                                    </div>
                                    <div class="option_availability">
                                        <div class="option_txt">Product Type </div>
                                        <div class="product_right_txt">
                                            Whole Grains
                                        </div>
                                    </div>
                                    <div class="option_availability">
                                        <div class="option_txt">Container Type </div>
                                        <div class="product_right_txt">
                                            Bottle
                                        </div>
                                    </div>
                                    <div class="option_availability">
                                        <div class="option_txt">Sales Package </div>
                                        <div class="product_right_txt">
                                            Oil Bottle (60 ml)
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-12">
                                <div class="track_del_address">
                                    Gohalpur New Basti No.1 Amkhera Road
                                </div>
                                <div class="track_status">
                                    <p><b>Delivered on 12-Apr-2018</b></p>
                                    <span class="del_status">Your item has been Delivered</span>
                                </div>
                            </div>
                        </div>
                        <div class="order_track">
                            <ol class="progtrckr" data-progtrckr-steps="5">
                                <li class="progtrckr-done">Ordered</li>
                                <li class="progtrckr-done">Packed</li>
                                <li class="progtrckr-done">Shipped</li>
                                <li class="progtrckr-done">Delivered</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('web.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.e_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>