<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .btn_center {
            text-align: center;
            margin-top: 10px;
        }

        .update_btn {
            display: none;
        }
        .hidealways {
            display: none;
        }
        .label_checkbox
        {
  display: inline-block;
        }

        .label_checkbox .cr{
            margin: 0px 5px;
        }
        .newrow
        {
            background: #1e81cd52 !important;
        }

    </style>

    <section class="box_containner">
        <div class="container-fluid">
            <div class="row">
               <section id="menu1">
                    <div class="home_brics_row">
                        <a href="/category"><div class="col-sm-3">
                            <div class="white_brics">
                                <div class="white_icon_withtxt">
                                    <div class="white_icons_blk"><i class="mdi mdi-tag"></i></div>
                                    <div class="white_brics_txt">Category</div>
                                    <div class="white_brics_count">150</div>
                                </div>
                                <div class="brics_progress white_brics_border_clr1"></div>
                            </div>
                        </div>
                        </a>

                        <a href="/items">
                        <div class="col-sm-3">
                            <div class="white_brics">
                                <div class="white_icon_withtxt">
                                    <div class="white_icons_blk white_brics_clr2"><i
                                                class="mdi mdi-content-duplicate"></i></div>
                                    <div class="white_brics_txt">Items</div>
                                    <div class="white_brics_count">150</div>
                                </div>
                                <div class="brics_progress white_brics_border_clr2" style="
"></div>
                            </div>
                        </div>
                        </a>
                         <a href="/userlist">
                        <div class="col-sm-3">
                            <div class="white_brics">
                                <div class="white_icon_withtxt">
                                    <div class="white_icons_blk white_brics_clr3"><i
                                                class="mdi mdi-account-multiple"></i></div>
                                    <div class="white_brics_txt">Users</div>
                                    <div class="white_brics_count">150</div>
                                </div>
                                <div class="brics_progress white_brics_border_clr3"></div>
                            </div>
                        </div>
                         </a>
                            <a href="/orderlist">
                        <div class="col-sm-3">
                            <div class="white_brics">
                                <div class="white_icon_withtxt">
                                    <div class="white_icons_blk white_brics_clr4"><i
                                                class="mdi mdi-clipboard-plus"></i></div>
                                    <div class="white_brics_txt">Orders</div>
                                    <div class="white_brics_count">150</div>
                                </div>
                                <div class="brics_progress white_brics_border_clr4"></div>
                            </div>
                        </div>
                            </a>

                    </div>
                </section>
              
            </div>
            <div class="row">
                <section id="menu1">
                    <div class="home_brics_row">

                        <a href="/delivery">
                            <div class="col-sm-3">
                                <div class="white_brics">
                                    <div class="white_icon_withtxt">
                                        <div class="white_icons_blk white_brics_clr4"><i
                                                    class="mdi mdi-gift"></i></div>
                                        <div class="white_brics_txt">Delivery</div>
                                        <div class="white_brics_count">150</div>
                                    </div>
                                    <div class="brics_progress white_brics_border_clr4"></div>
                                </div>
                            </div>
                        </a>


                        <a href="/review">
                            <div class="col-sm-3">
                                <div class="white_brics">
                                    <div class="white_icon_withtxt">
                                        <div class="white_icons_blk white_brics_clr3"><i
                                                    class="mdi mdi-forum"></i></div>
                                        <div class="white_brics_txt">Review</div>
                                        <div class="white_brics_count">150</div>
                                    </div>
                                    <div class="brics_progress white_brics_border_clr3"></div>
                                </div>
                            </div>
                        </a>



                        <a href="/statelist">
                            <div class="col-sm-3">
                                <div class="white_brics">
                                    <div class="white_icon_withtxt">
                                        <div class="white_icons_blk white_brics_clr2"><i
                                                    class="mdi mdi-earth"></i></div>
                                        <div class="white_brics_txt">State</div>
                                        <div class="white_brics_count">150</div>
                                    </div>
                                    <div class="brics_progress white_brics_border_clr2" style="
"></div>
                                </div>
                            </div>
                        </a>

                        <a href="/citylist"><div class="col-sm-3">
                                <div class="white_brics">
                                    <div class="white_icon_withtxt">
                                        <div class="white_icons_blk"><i class=" mdi mdi-map-marker"></i></div>
                                        <div class="white_brics_txt">City</div>
                                        <div class="white_brics_count">150</div>
                                    </div>
                                    <div class="brics_progress white_brics_border_clr1"></div>
                                </div>
                            </div>
                        </a>

                    </div>
                </section>
                
            </div>
            <div class="row">
                <section id="menu1">
                    <div class="home_brics_row">


                        <a href="/ask"><div class="col-sm-3">
                                <div class="white_brics">
                                    <div class="white_icon_withtxt">
                                        <div class="white_icons_blk"><i class="mdi mdi-cellphone-android"></i></div>
                                        <div class="white_brics_txt">Ask Caller</div>
                                        <div class="white_brics_count">150</div>
                                    </div>
                                    <div class="brics_progress white_brics_border_clr1"></div>
                                </div>
                            </div>
                        </a>
                        <a href="/blog">
                            <div class="col-sm-3">
                                <div class="white_brics">
                                    <div class="white_icon_withtxt">
                                        <div class="white_icons_blk white_brics_clr2"><i
                                                    class="mdi mdi-message-image"></i></div>
                                        <div class="white_brics_txt">Blog</div>
                                        <div class="white_brics_count">150</div>
                                    </div>
                                    <div class="brics_progress white_brics_border_clr2" style="
"></div>
                                </div>
                            </div>
                        </a>

                    </div>
                </section>


                
            </div>
        </div>
    </section>





    


    <script>
       
    </script>


    


    <script>
        function validate() {
            var cat_name = $('#cat_name').val();
            var cat_description = $('#cat_description').val();
            if (cat_name == "") {
                $('#cat_name').addClass("w3-border-red");
                return false;
            }
            else if (cat_description == "") {
                $('#cat_description').addClass("w3-border-red");
                return false;

            }
            else {
                sendcat();
            }
        }

        function sendcat() {
            var cat_name = $('#cat_name').val();
            var cat_description = $('#cat_description').val();
            $.ajax({
                type: "post",
                url: "<?php echo e(url('add_cat')); ?>",
                data: "cat_name= " + cat_name + "&cat_description= " + cat_description,
                success: function (data) {
                    $('#snackbar').html('');
                    $('#snackbar').html('Categories added successfully');
                    $('#myModal').modal('hide');
                    myFunction();
                    $("#item_form").load(location.href + " #item_form");
                    $("#mytablereload").load(location.href + " #mytablereload");


                },
                error: function (data) {

                }
            });
        }

        $(document).ready(function () {
            $('#open_item_form').click(function () {
                $('#item_list').hide();
                $('#item_form').show();
            });
            $('#open_modal').click(function () {
                $('#myheader').html('');
                $('#mybody').html('');
                $('#myfooter').html('');
                $('#myheader').append('<div><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title">Add Categories</h4></div>');
                $('#mybody').append('<div class="panel-body dash_table_containner"><input type="text" class="form-control vRequiredTex" name="cat_name" placeholder="Enter Your Category Name " id="cat_name"><p class="clearfix"></p><textarea name="cat_description" id="cat_description" class="form-control vRequiredTex" rows="4" cols="50" placeholder="Enter Your Description "></textarea></p></div>');
                $('#myfooter').append('<button id="add_btn" type="button" class="btn btn-default" data-dismiss="modal">Close</button><button onclick="validate();" class="btn btn-primary">Add</button>');
                $('#myModal').modal();
            });
        });

    </script>
    <script>
        function myFunction() {
            var x = document.getElementById("snackbar");
            x.className = "show";
            setTimeout(function () {
                x.className = x.className.replace("show", "");
            }, 3000);

        }

        function abcd($id) {
            $('.edittable' + $id).attr('contenteditable', 'true');
            $('.edit' + $id).hide();
            $('.update' + $id).show();

        }
        function abcdd($id) {
            $('.edittable' + $id).attr('contenteditable', 'false');
            $('.edit' + $id).show();
            $('.update' + $id).hide();

        }
        function abcddd($id) {
            $('.edittable' + $id).attr('contenteditable', 'false');
            $('.edit' + $id).show();
            $('.update' + $id).hide();
            $('.hiderow' + $id).hide();

        }
        function update(dis, id) {
            var ID = id;
            var name = $(dis).parent().parent("#" + id).children('.name').html();
            var slug = $(dis).parent().parent("#" + id).children('.slug').html();
            var des = $(dis).parent().parent("#" + id).children('.description').html();
            /*alert(ID+one+two+three);*/
            $.ajax({
                type: "post",
                url: "<?php echo e(url('updatecat')); ?>",
                data: "name= " + name + "&slug= " + slug + "&des= " + des + "&ID= " + ID,
                success: function (data) {
                    abcdd(ID);
                    $('#snackbar').html('');
                    $('#snackbar').html('Categories Updated successfully');
                    myFunction();
                    $("#item_form").load(location.href + " #item_form");


                },
                error: function (data) {
                    alert("Error")
                }
            });


        }
        function deletecat(id) {
            var ID = id;
            $.ajax({
                type: "post",
                url: "<?php echo e(url('deletecat')); ?>",
                data: "&ID= " + ID,
                success: function (data) {
                    abcddd(ID);
                    $('#snackbar').html('')
                    $('#snackbar').html('Successfully Deleted');
                    myFunction();
                    $("#item_form").load(location.href + " #item_form");

                },
                error: function (data) {
                    alert("Error")
                }
            });

        }

    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlayout.adminmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>