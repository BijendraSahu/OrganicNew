<?php $__env->startSection('title','Organic Dolchi | OrderList'); ?>

<?php $__env->startSection('content'); ?>

    <style>
        .dropbtn {
            background-color: #4CAF50;
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {background-color: #ddd;}

        .dropdown:hover .dropdown-content {display: block;}

        .dropdown:hover .dropbtn {background-color: #3e8e41;}
    </style>

    <section class="box_containner" id="fullid">
        <div class="container-fluid">
            <div class="row">
                <section id="menu2">
                    <div class="col-sm-12 col-md-12 col-xs-12">
                        <div class="dash_boxcontainner white_boxlist">
                            <div class="upper_basic_heading"><span class="white_dash_head_txt">
                       All Orders
                                    
                    </span>

                                <div id="snackbar">New Categories added Successfully</div>
                                <p class="clearfix"></p><input id='myInput' class="form-control" placeholder="search" onkeyup='searchTable()' type='text'>
                                <br>
                                <section id="user_table">
                                    <table class="table table-striped" id='myTable'>
                                        <thead>
                                        <tr>
                                            <th>Order No</th>
                                            <th>Date</th>
                                            <th>User</th>
                                            <th>Active / Inactive</th>

                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php $__currentLoopData = $orderdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($order_object->order_no); ?></td>
                                                <td><?php echo e($order_object->order_date); ?></td>
                                                <td><?php echo e($order_object->user_id); ?></td>
                                                <td>
                                                    <?php if($order_object->is_active=='1'): ?>
                                                        <div class="status pending">Active</div>
                                                        <?php else: ?>
                                                        <div class="status approved">Inactive</div>
                                                        <?php endif; ?>
                                                </td>

                                                <td><?php echo e($order_object->status); ?></td>
                                                <td>
                                                    <div class="dropdown">
                                                        <button class="btn btn-success btn-sm">Status Change</button>
                                                        <div class="dropdown-content">
                                                            <a onclick="ordered(<?php echo e($order_object->id); ?>);" href="#">Ordered</a>
                                                            <a onclick="packed(<?php echo e($order_object->id); ?>);" href="#">Packed</a>
                                                            <a onclick="shipped(<?php echo e($order_object->id); ?>);" href="#">Shipped</a>
                                                            <a onclick="delivered(<?php echo e($order_object->id); ?>);" href="#">Delivered</a>
                                                        </div>
                                                    </div>&nbsp;&nbsp;<div class="dropdown">
                                                        <button class="btn btn-success btn-sm">ON/OFF</button>
                                                        <div class="dropdown-content">
                                                            <a onclick="active(<?php echo e($order_object->id); ?>);" href="#">Active</a>
                                                            <a onclick="inactive(<?php echo e($order_object->id); ?>);" href="#">InActive</a>
                                                        </div>
                                                    </div>&nbsp;&nbsp;<a href='<?php echo e(url("/bill_order/{$order_object->id}")); ?>' target="_blank"><button class="btn btn-primary btn-sm">Bill &nbsp;<i class="mdi mdi-clipboard-text"></i></button></a>&nbsp;&nbsp;<button onclick="more_full(<?php echo e($order_object->id); ?>);" class="btn btn-primary btn-sm">More &nbsp;<i class="mdi mdi-eye"></i></button></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        </tbody>
                                    </table>

                                </section>



                            </div>


                        </div>
                    </div>
                </section>



            </div>
        </div>
    </section>
    <script>

            function more_full(id) {
                $('#myheader').html('');
                $('#mybody').html('');
                $('#myfooter').html('');
                $('#myheader').html('Order Full View  <button type="button" class="close"  data-dismiss="modal">&times;</button>');
                $('#myfooter').html('<button type="button"  class="btn btn-default" data-dismiss="modal">Close</button>');


                /*alert(id);*/
                /*var IDD= id;*/
                var editurl1 = '<?php echo e(url('more_order')); ?>' + '/' + id;
                $.ajax({
                    type: "GET",
                    contentType: "application/json; charset=utf-8",
                    url: editurl1,
                    data: '{"data":"' + id + '"}',
                    success: function (data) {
                        $('#myModal').modal();
                        $('.modal-body').html(data);

                    },
                    error: function (xhr, status, error) {
                        $('.modal-body').html(xhr.responseText);
                        //$('.modal-body').html("Technical Error Occured!");
                    }
                });



        }



        function active(id)
        {
            var IDD = id;
            $.ajax({
                type: "get",
                url: "<?php echo e(url('/active_order')); ?>",
                data: "IDD= " + IDD ,
                success: function (data) {
                    $("#user_table").load(location.href + " #user_table");
                    myFunction();
                    $('#snackbar').html('');
                    $('#snackbar').addClass('show');
                    $('#snackbar').html('order is active');

                },
                error: function (data) {

                }
            });

        }
        function inactive(id)
        {
            var IDD = id;
            $.ajax({
                type: "get",
                url: "<?php echo e(url('/inactive_order')); ?>",
                data: "IDD= " + IDD ,
                success: function (data) {
                    $("#user_table").load(location.href + " #user_table");
                    myFunction();
                    $('#snackbar').html('');
                    $('#snackbar').addClass('show');
                    $('#snackbar').html('order is inactive');

                },
                error: function (data) {

                }
            });

        }
        function ordered(id)
        {
          var IDD = id;
            $.ajax({
                type: "get",
                url: "<?php echo e(url('/ordered')); ?>",
                data: "IDD= " + IDD ,
                success: function (data) {
                    $("#user_table").load(location.href + " #user_table");
                    myFunction();
                    $('#snackbar').html('');
                    $('#snackbar').addClass('show');
                    $('#snackbar').html('status Change Into Orderd');

                },
                error: function (data) {

                }
            });

         }
        function packed(id)
        {
            var IDD = id;
            $.ajax({
                type: "get",
                url: "<?php echo e(url('/packed')); ?>",
                data: "IDD= " + IDD ,
                success: function (data) {
                    $("#user_table").load(location.href + " #user_table");
                    myFunction();
                    $('#snackbar').html('');
                    $('#snackbar').addClass('show');
                    $('#snackbar').html('status Change Into packed');

                },
                error: function (data) {

                }
            });
        }
        function shipped(id)
        {
            var IDD = id;
            $.ajax({
                type: "get",
                url: "<?php echo e(url('/shipped')); ?>",
                data: "IDD= " + IDD ,
                success: function (data) {
                    $("#user_table").load(location.href + " #user_table");
                    myFunction();
                    $('#snackbar').html('');
                    $('#snackbar').addClass('show');
                    $('#snackbar').html('status Change Into Shipped');

                },
                error: function (data) {

                }
            });
        }
        function delivered(id)
        {
            var IDD = id;
            $.ajax({
                type: "get",
                url: "<?php echo e(url('/delivered')); ?>",
                data: "IDD= " + IDD ,
                success: function (data) {
                    $("#user_table").load(location.href + " #user_table");
                    myFunction();
                    $('#snackbar').html('');
                    $('#snackbar').addClass('show');
                    $('#snackbar').html('status Change Into Delivered');

                },
                error: function (data) {

                }
            });
        }



    </script>
    <script>
        function searchTable() {
            var input, filter, found, table, tr, td, i, j;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td");
                for (j = 0; j < td.length; j++) {
                    if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                        found = true;
                    }
                }
                if (found) {
                    tr[i].style.display = "";
                    found = false;
                } else {
                    tr[i].style.display = "none";
                }
            }
        }


    </script>





    



    
<?php $__env->stopSection(); ?>





<?php echo $__env->make('adminlayout.adminmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>