<div align="center"><h3><?php echo e(ucfirst($all_items->name)); ?></h3></div>


<h4 class="pro_title"><b>Price :</b></h4>
    <?php $__currentLoopData = $all_items_price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objmy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><b>Unit</b> :<?php echo e($objmy->unit); ?>&nbsp;&nbsp; <b>Quantity</b> :<?php echo e($objmy->qty); ?> &nbsp;&nbsp; <b>price</b> :<?php echo e($objmy->price); ?>&nbsp;&nbsp;  <b>Special Price</b>:<?php echo e($objmy->spl_price); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<h4 class="pro_title"><b>Selected Catagrious:</b></h4>
    <?php $__currentLoopData = $all_items_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objmycat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($objmycat->cat_name->name); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<h4  class="pro_title"><b>Delivery :</b></h4>
    <p><?php echo e(ucfirst($all_items->delivery)); ?></p>


<h4  class="pro_title"><b>Specifications :</b></h4>
    <p><?php echo e(ucfirst($all_items->specifcation)); ?></p>



<h4  class="pro_title"><b>Ingredients :</b></h4>
    <p><?php echo e(ucfirst($all_items->ingredients)); ?></p>


<h4  class="pro_title"><b>Available Nutrients :</b></h4>
    <p><?php echo e(ucfirst($all_items->nutrients)); ?></p>


<h4 class="pro_title"><b>Description :</b></h4>
    <p><?php echo e(ucfirst($all_items->description)); ?></p>


<h4 class="pro_title"><b>Usage :</b></h4>
    <p><?php echo e(ucfirst($all_items->usage)); ?></p>


<h4 class="pro_title"><b>Images :</b></h4>
<div>
    <?php $__currentLoopData = $all_items_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgobj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img style="height: 125px;" src="p_img\<?php echo e($imgobj->item_master_id); ?>\<?php echo e($imgobj->image); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<style type="text/css">
    .pro_title{
        border-bottom: 1px solid #353a351c;
        font-size: 20px;
        padding-bottom: 12px;
    }

</style>
