<?php $__env->startSection('title','Organic Dolchi | Ask For Call'); ?>

<?php $__env->startSection('content'); ?>


    <section class="box_containner" id="fullid">
        <div class="container-fluid">
            <div class="row">
                <section id="item_part1">
                    <section id="item_list">
                        <div class="col-sm-12 col-md-12 col-xs-12">
                            <div class="dash_boxcontainner white_boxlist">
                                <div class="upper_basic_heading"><span class="white_dash_head_txt">
                         Caller List
                         
                      </span>
                                    <p class="clearfix"></p>
                                    <table class="table table-striped">
                                        <thead>
                                        <tr>
                                            <th scope="col">S.No.</th>
                                            <th scope="col">Mobile Number</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>1</td>
                                            <td><?php echo e($object->mobile); ?></td>
                                        </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>



                                    </table>
                                </div>
                            </div>
                        </div>
                    </section>
                </section>



            </div>
        </div>
    </section>




<?php $__env->stopSection(); ?>





<?php echo $__env->make('adminlayout.adminmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>