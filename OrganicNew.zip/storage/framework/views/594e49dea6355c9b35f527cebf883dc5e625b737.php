<link rel="shortcut icon" type="images/png" href="<?php echo e(url('images/favicon-prihul.png')); ?>"/>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="<?php echo e(url('css/bootstrap.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(url('css/materialdesignicons.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(url('css/flaticon.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(url('css/frount.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(url('css/media.css')); ?>"/>
<script src="<?php echo e(url('js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('js/Global.js')); ?>"></script>
<script src="<?php echo e(url('js/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(url('js/my_validation.js')); ?>"></script>
<link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" rel="stylesheet"/>
