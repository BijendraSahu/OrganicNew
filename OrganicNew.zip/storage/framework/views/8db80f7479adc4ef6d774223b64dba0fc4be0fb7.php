
<style>
    .error_register {
        color: red;
        font-weight: bold;
        padding-top: 58px;
    }
    </style>
<nav class="main_menu fixed_menu" id="top_header_menu">
    <div class="container">
        <div class="row top_menubox">
            <div class="main_logo">
                <a href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(url('images/white_logo_single2.png')); ?>">
                </a>
            </div>
            <div class="menu_all_containner">
                <div class="testominial_box">
                    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="item active">
                                <div class="testominial_row">
                                    <img class="testominial_img" src="<?php echo e(url('images/testominial_img5.jpg')); ?>">
                                    <div class="testominial_txtbox">
                                        <h4>- Anurag Agrawal</h4>
                                        <p>EAT PURE KEEP FIT EAT PURE KEEP FITEAT PURE KEEP FITEAT PURE KEEP FITEAT PURE
                                            KEEP FITEAT PURE KEEP FIT</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testominial_row">
                                    <img class="testominial_img" src="<?php echo e(url('images/testominial_img4.jpg')); ?>">
                                    <div class="testominial_txtbox">
                                        <h4>- Sandhya Borkar</h4>
                                        <p>At Organic Dolchi store kachnar At Organic Dolchi store kachnar At Organic
                                            Dolchi store kachnar At Organic Dolchi store kachnar</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testominial_row">
                                    <img class="testominial_img" src="<?php echo e(url('images/testominial_img3.jpg')); ?>">
                                    <div class="testominial_txtbox">
                                        <h4>- Ashish Katiyar</h4>
                                        <p>At Organic Dolchi store kachnar At Organic Dolchi store kachnar At Organic
                                            Dolchi store kachnar At Organic Dolchi store kachnar</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testominial_row">
                                    <img class="testominial_img" src="<?php echo e(url('images/Admin_pic.jpg')); ?>">
                                    <div class="testominial_txtbox">
                                        <h4>- Pinku Kesharwani</h4>
                                        <p>At Organic Dolchi store kachnar At Organic Dolchi store kachnar At Organic
                                            Dolchi store kachnar</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="login_with_baskit">
                    <ul>

                        <?php session_start(); ?>

                        <?php if(!isset($_SESSION['user_master'])): ?>
                            <li onclick="ShowLoginSignup('signin');">Sign In</li>
                            <li onclick="ShowLoginSignup('signup');">Sign Up</li>
                        <?php else: ?>
                            <li>
                                <div class="my_account_box glo_menuclick">My Account
                                    <div class="menu_basic_popup menu_popup_account scale0">
                                        <div class="menu_popup_account">
                                            <div class="menu_popup_settingrow">
                                                <a href="<?php echo e(url('/')); ?>" class="menu_setting_row">
                                                    <i class="mdi mdi-home"></i>
                                                    Home
                                                </a>
                                            </div>
                                            <div class="menu_popup_settingrow">
                                                <a href="<?php echo e(url('my_profile')); ?>" class="menu_setting_row">
                                                    <i class="mdi mdi-account-edit"></i>
                                                    Edit Profile
                                                </a>
                                            </div>
                                            <div class="menu_popup_settingrow">
                                                <a href="<?php echo e(url('product_list')); ?>" class="menu_setting_row">
                                                    <i class="mdi mdi-basket"></i>
                                                    Product List
                                                </a>
                                            </div>
                                            <div class="menu_popup_settingrow">
                                                <a href="<?php echo e(url('order_list')); ?>" class="menu_setting_row">
                                                    <i class="mdi mdi-format-list-checks"></i>
                                                    Order List
                                                </a>
                                            </div>
                                            <div class="menu_popup_settingrow">
                                                <a href="<?php echo e(url('product_feedback')); ?>" class="menu_setting_row">
                                                    <i class="mdi mdi-message-draw"></i>
                                                    Review &amp; Rating
                                                </a>
                                            </div>
                                            <div onclick="ChangePasswordShow();" class="menu_popup_settingrow"
                                                 data-target="#myModal_UpdatePassword" data-toggle="modal">
                                                <a class="menu_setting_row" href="#">
                                                    <i class="mdi mdi-lock-open-outline"></i>
                                                    Change Password
                                                </a>
                                            </div>
                                            <div class="menu_popup_settingrow">
                                                <a href="<?php echo e(url('logout')); ?>" class="menu_setting_row">
                                                    <i class="mdi mdi-logout"></i>
                                                    Logout
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        <?php endif; ?>
                        <li style="border-right: none;">
                            <div class="baskit_containner glo_menuclick" id="cartload">

                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="fixed_button fixed_top" id="top_scroll_btn" onclick="ScrollBottom();">
    <i class="mdi mdi-mdi mdi-arrow-expand-down"></i>
</div>
<div class="fixed_button fixed_bottom" id="bottom_scroll_btn" onclick="ScrollTop();">
    <i class="mdi mdi-mdi mdi-arrow-expand-up"></i>
</div>
<div class="fixed_asked" data-toggle="tooltip" data-placement="left" title="Ask For Call" id="ask_call">
    <span class="" data-toggle="modal" data-target="#AskForCall">
    <i class="mdi mdi-phone"></i>
    </span>
</div>
<div class="modal right fade" id="AskForCall" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel2" style="color: #0dae0d;">Ask For Call</h4>
                <div class="headphone_forask">
                    <i class="mdi mdi-headphones-settings"></i>
                </div>
            </div>
            <div class="modal-body">
                <div class="deli_row">
                    <input type="text" name="ask_number" autocomplete="off" class="form-control login_txt"
                           placeholder="Enter Mobile Number"/>
                </div>
            </div>
            <div class="modal-footer text-center">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="AskSubmit">Submit</button>
            </div>
        </div>
    </div>
</div>
<div id="myModal_UpdatePassword" class="modal fade" role="dialog" aria-hidden="false">
    <div class="modal-dialog forgotpass_lb">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">×</button>
                <h4 class="modal-title">UPDATE PASSWORD ?</h4>
            </div>
            <div class="modal-body">
                <div class="basic_lb_row">
                    <input type="text" class="form-control forgot_txt" placeholder="Old Password"
                           id="txtChange_previousPsd" autocomplete="off" data-validate="TT_btnChangepass">
                    <div class="forgot_icon"><i class="mdi mdi-lock mdi-16px"></i></div>
                </div>
                <div class="basic_lb_row">
                    <input type="text" class="form-control forgot_txt" placeholder="New Password" id="txtchange_newPsd"
                           autocomplete="off" data-validate="TT_btnChangepass">
                    <div class="forgot_icon"><i class=" mdi mdi-lock-open-outline mdi-16px"></i></div>
                </div>
                <div class="basic_lb_row">
                    <input type="text" class="form-control forgot_txt" placeholder=" Re-type Password"
                           id="txtchange_retypePsd" autocomplete="off" data-validate="TT_btnChangepass">
                    <div class="forgot_icon"><i class=" mdi mdi-lock-open-outline mdi-16px"></i></div>
                </div>
            </div>
            <div class="modal-footer text-center">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="TT_btnChangepass">Update</button>
            </div>
        </div>

    </div>
</div>
<!------Popup Box -->
<div class="modal popup_bgcolor" id="sucess_popup">
    <div class="popup_box">
        <div class="alert_popup success_bg">
            <div class="popup_verified"><i class="mdi mdi-check"></i></div>
            <h4 class="popup_mainhead">Thank You!</h4>
            <p class="popup-text dynamic_popuptxt">You have successfully Submit</p>
        </div>
        <div class="popup_submit">
            <button class="popup_submitbtn success_bg sucess_btn" type="submit" onclick="HidePopoupMsg();">Ok
            </button>
        </div>
    </div>
</div>
<div class="modal popup_bgcolor" id="error_popup">
    <div class="popup_box">
        <div class="alert_popup error_bg">
            <div class="popup_verified"><i class="mdi mdi-close"></i></div>
            <h4 class="popup_mainhead">Error Massage!</h4>
            <p class="popup-text dynamic_popuptxt">You have entered wrong text</p>
        </div>
        <div class="popup_submit">
            <button class="popup_submitbtn error_bg error_btn" type="submit" onclick="HidePopoupMsg();">ok</button>
        </div>
    </div>
</div>
<div class="modal popup_bgcolor" id="conformation_popup">
    <div class="popup_box">
        <div class="alert_popup conformation_bg">
            <div class="popup_verified"><i class="mdi mdi-close"></i></div>
            <h4 class="popup_mainhead">Confirmation Massage!</h4>
            <p class="popup-text dynamic_popuptxt">Do you really want to delete this record.t</p>
        </div>
        <div class="popup_submit">
            <a class="popup_submitbtn conformation_bg conformation_btn" type="submit" id="ConfirmBtn"
               onclick="HidePopoupMsg();">Yes
            </a>
            <a class="popup_submitbtn conformation_nobtn" type="submit" onclick="HidePopoupMsg();">No</a>
        </div>
    </div>
</div>

<div class="modal popup_bgcolor" id="loginSignup_popup">
    <div class="login_popup_box">
        <div class="close_login" onclick="HidePopoupMsg();"><i class="mdi mdi-close"></i></div>
        <div class="login_lefttxtbox">
            <div class="left_block login">
                <h1>Login</h1>
                <p>Get access to your Orders, and Recommendations.</p>
                <img src="images/signin_images.png">
            </div>
            <div class="left_block registration">
                <h1>Registration</h1>
                <p>We do not share your personal details with anyone.</p>
                <img src="images/signup_image.png">
                <div class="error_register">
                    <p id="error_register"></p>
                </div>
            </div>
            <div class="left_block forgot">
                <h1>Forgot</h1>
                <p>Enter mobile phone number associated with your Organic Dolchi account.</p>
                <img src="images/forgot_image.png"/>
            </div>
        </div>
        <div class="login_right_txt">
            <div class="right_block login">
                <form action="<?php echo e(url('login')); ?>" method="post" enctype="multipart/form-data"
                      class="form-horizontal" id="frmLogin">
                    <div class="deli_row">
                        <input type="text" name="email_pass" autocomplete="off" class="form-control login_txt"
                               placeholder="Email/Mobile Number " id="login_mobile">
                    </div>
                    <div class="deli_row">
                        <input type="password" name="login_password" autocomplete="off" class="form-control login_txt"
                               placeholder="Password" id="login_password">
                    </div>
                    <hr>
                    <div class="deli_row">
                        <button onclick="send_login();" class="btn btn-success login_btn" type="button">
                            <i class="mdi mdi-account-check basic_icon_margin"></i>Submit
                        </button>
                    </div>
                </form>
                <hr>
                <div class="product_btn_box">
                    <div class="btn btn-warning" onclick="ShowLoginSignup('forgot')">
                        <i class="mdi mdi-account-alert basic_icon_margin"></i>Forgot
                    </div>
                    <div class="btn btn-primary pull-right" onclick="ShowLoginSignup('signup');">
                        <i class="mdi mdi-account-edit basic_icon_margin"></i>Sign Up
                    </div>
                </div>
            </div>
            <div class="right_block forgot">
                <div class="deli_row">
                    <input type="text" name="email_pass" autocomplete="off" class="form-control login_txt"
                           placeholder="Enter Mobile Number ">
                </div>
                <hr>
                <div class="deli_row">
                    <button class="btn btn-success login_btn">
                        <i class="mdi mdi-account-check basic_icon_margin"></i>Submit
                    </button>
                </div>
                <hr>
                <div class="product_btn_box">
                    <div class="btn btn-primary login_btn" onclick="ShowLoginSignup('signin');">
                        <i class="mdi mdi-account-edit basic_icon_margin"></i>Sign In
                    </div>
                </div>
            </div>
            <div class="right_block registration">
                <div class="deli_row">
                    <input type="text" name="referal_code" autocomplete="off" class="form-control login_txt"
                           placeholder="Referral Code" id="ref_code" >
                </div>
                <div class="deli_row">
                    <input type="text" name="reg_name" autocomplete="off" class="form-control login_txt"
                           placeholder="Enter Name" id="name">
                </div>
                <div class="deli_row">
                    <input type="text" name="reg_email" autocomplete="off" class="form-control login_txt"
                           placeholder="Enter Email Id" id="email_id">
                </div>
                <div class="deli_row">
                    <input type="text" name="reg_number" autocomplete="off" class="form-control login_txt"
                           placeholder="Enter Mobile Number" id="mobile">
                </div>
                <div class="deli_row">
                    <input type="password" name="reg_password" autocomplete="off" class="form-control login_txt"
                           placeholder="Enter Password" id="password">
                </div>
                <div class="deli_row">
                    <input type="password" name="reg_password" autocomplete="off" class="form-control login_txt"
                           placeholder="Confirmation Password" id="confirm_password">
                </div>
                <div class="deli_row">
                    <button onclick="check();" class="btn btn-success login_btn">
                        <i class="mdi mdi-account basic_icon_margin"></i>Registerd
                    </button>
                </div>
                <hr>
                <div class="deli_row">
                    <button class="btn btn-default login_btn" onclick="ShowLoginSignup('signin');">
                        <i class="mdi mdi-account-check basic_icon_margin"></i>Existing User? Log In
                    </button>
                </div>

            </div>
        </div>
    </div>
</div>
<!--<style type="text/css">

</style>
<script type="text/javascript">

</script>-->
<script type="text/javascript">
    function check()
    {
        var email= $('#email_id').val();
        var mobile=$('#mobile').val();
        var password=$('#password').val();
        var confirm_password=$('#confirm_password').val();
        var phoneno = /^\d{10}$/;
        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        if (reg.test(email) == false)
        {
            HidePopoupMsg();
            ShowErrorPopupMsg('Please Enter valid Email Address');
            return false;
        }
        else if( phoneno.test(mobile)== false)
        {
            HidePopoupMsg();
            ShowErrorPopupMsg('Please Enter valid Mobile Number');
            return false;

        }
        else if(password!=confirm_password)
        {
            HidePopoupMsg();
            ShowErrorPopupMsg('Password MisMatch');
            return false;

        }

        else {
            register_user();
        }

    }
    
    
    function register_user()
    {
      var ref_code=$('#ref_code').val();
      var user_name=$('#name').val();
      var email_id=$('#email_id').val();
      var mobile=$('#mobile').val();
      var password=$('#password').val();
      var confirm_password=$('#confirm_password').val();
        $.ajax({
            type: "get",
            url: "<?php echo e(url('register_user')); ?>",
            data: "ref_code= " + ref_code + "&user_name= " + user_name + "&email_id= " + email_id + "&mobile= " + mobile + "&password= " + password ,
            success: function (data) {

                if(data=='Mobile Number Already Linked With Another Account!!!!!!')
                {
                    $('#error_register').html('Mobile Number Already Linked With Another Account!!!!!!');
                }
                else if(data=='email Address is Already Linked With Another Account!!!')
                {
                    $('#error_register').html('email Address is Already Linked With Another Account!!!');
                }
                else{
                    $('#error_register').html('');
                    HidePopoupMsg();
              $('#ref_code').val('');
               $('#name').val('');
               $('#email_id').val('');
          $('#mobile').val('');
          $('#password').val('');
           $('#confirm_password').val('');
                    ShowSuccessPopupMsg('User Registration Successfully...');
                }
            },
            error: function (data) {
                HidePopoupMsg();
                ShowErrorPopupMsg('oops Something Went Wronge...');
            }
        });
    }


function send_login()
{
    var login_mobile =$('#login_mobile').val();
    var login_password=$('#login_password').val();

    $.ajax({
        type: "POST",
        url: "<?php echo e(url('login_user')); ?>",
        data: "login_mobile= " + login_mobile + "&login_password= " + login_password ,
        success: function (data) {
if(data=="UserName/Password Invalid")
{
    HidePopoupMsg();
    ShowErrorPopupMsg('UserName/Password Invalid');
}
else {
    HidePopoupMsg();
    ShowSuccessPopupMsg('Login Success');
    window.location.reload();
}
        },
        error: function (data) {
            alert(data);
        }
    });
}

    $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>