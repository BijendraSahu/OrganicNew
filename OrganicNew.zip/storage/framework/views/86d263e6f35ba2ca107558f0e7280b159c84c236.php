<!DOCTYPE >
<html lang="en">
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>">
    <?php echo $__env->make('web.layouts.plugin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script type=text/javascript>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <style type="text/css">
        .errorClass {
            border: 1px solid red;
        }

    </style>
    <style>
        html, body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Raleway', sans-serif;
            font-weight: 100;
            height: 100vh;
            margin: 0;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links > a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
</head>
<body class="body_color">
<?php echo $__env->make('web.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="flex-center position-ref full-height">

    <div class="content">
        <div class="title m-b-md">
            Something went wrong
        </div>

        <div class="links">
            <a href="<?php echo e(url('logout')); ?>">Click here</a>
            
            
            
            
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        var editurl = "<?php echo e(url('cart_load')); ?>";
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: editurl,
            data: '{"data":"' + "cart" + '"}',
            success: function (data) {
                $("#cartload").html(data);
            },
            error: function (xhr, status, error) {
                $('#cartload').html(xhr.responseText);
//                    alert('Error');
            }
        });
    });
</script>
</body>
</html>
