<?php $__env->startSection('title', 'Organic Food : Order List'); ?>

<?php $__env->startSection('content'); ?>
    <section class="product_section">
        <div class="container">
            <div class="order_listbox">
                <div class="carousal_head">
                    <span class="filter_head_txt slider_headtxt">My Orders List</span>
                </div>
                <div class="order_list_container">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="order_row">
                            <div class="order_header">
                                <div class="order_no">OrganicDolchi<?php echo e($order->order_no); ?></div>
                                <div class="order_amt pull-right"><i class="mdi mdi-currency-inr"></i> <?php echo e($order->total); ?>

                                </div>
                            </div>
                            <?php
                                $item = \App\ItemMaster::find($order->item_master_id);
                            ?>
                            <div class="order_details_box">
                                <div class="col-md-8 col-sm-12">
                                    <div class="productdetails_order_row">
                                        <div class="order_product_imgbox">
                                            <?php
                                                $image = \App\ItemImages::where(['item_master_id' => $item->id])->first();
                                            ?>
                                            <?php if(isset($image)): ?>
                                                <img src="<?php echo e(url('p_img').'/'.$item->id.'/'.$image->image); ?>">
                                            <?php else: ?>
                                                <img src="<?php echo e(url('images/default.png')); ?>" alt="Organic product">
                                            <?php endif; ?>
                                        </div>
                                        <div class="product_name">
                                            <a class="product_details_link"
                                               href="<?php echo e(url('view_product').'/'.(encrypt($item->id))); ?>"> <?php echo e($item->name); ?></a>
                                        </div>
                                        <div class="option_availability">
                                            <div class="option_txt">Specification</div>
                                            <div class="product_right_txt">
                                                <?php echo $item->specifcation; ?>

                                            </div>
                                        </div>
                                        <div class="option_availability">
                                            <div class="option_txt">Qty</div>
                                            <div class="product_right_txt">
                                                <?php echo e($order->qty); ?>

                                            </div>
                                        </div>
                                        
                                            
                                            
                                                
                                            
                                        
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12">
                                    <div class="track_del_address">
                                        <?php
                                            $address = \App\UserAddress::find($order->address_id);
                                        ?>
                                        <?php echo e(isset($address)?$address->name.', '.$address->contact.', '.$address->address.', '.$address->address2.', '.$address->zip:'-'); ?>

                                    </div>
                                    <div class="track_status">
                                        <p><b>Item <?php echo e($order->status); ?>

                                                on <?php echo e(date_format(date_create($order->updated_time), "d-M-Y ")); ?></b></p>
                                        <span class="del_status">Your item has been <?php echo e($order->status); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="order_track">
                                <ol class="progtrckr" data-progtrckr-steps="5">
                                    <?php if($order->status=='Ordered'): ?>
                                        <li class="progtrckr-done">Ordered</li>
                                        <li class="progtrckr-todo">Packed</li>
                                        <li class="progtrckr-todo">Shipped</li>
                                        <li class="progtrckr-todo">Delivered</li>
                                    <?php elseif($order->status=='Packed'): ?>
                                        <li class="progtrckr-done">Ordered</li>
                                        <li class="progtrckr-done">Packed</li>
                                        <li class="progtrckr-todo">Shipped</li>
                                        <li class="progtrckr-todo">Delivered</li>
                                    <?php elseif($order->status=='Shipped'): ?>
                                        <li class="progtrckr-done">Ordered</li>
                                        <li class="progtrckr-done">Packed</li>
                                        <li class="progtrckr-done">Shipped</li>
                                        <li class="progtrckr-todo">Delivered</li>
                                    <?php elseif($order->status=='Delivered'): ?>
                                        <li class="progtrckr-done">Ordered</li>
                                        <li class="progtrckr-done">Packed</li>
                                        <li class="progtrckr-done">Shipped</li>
                                        <li class="progtrckr-done">Delivered</li>
                                    <?php endif; ?>

                                </ol>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('web.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.e_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>