<input type="hidden" id="products_count" value="<?php echo e($items_count); ?>"/>
<?php if(count($items) > 0): ?>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product_block">
            <div class="product_name"><a class="product_details_link" href="<?php echo e(url('view_product').'/'.(encrypt($item->id))); ?>"><?php echo e($item->name); ?></a></div>
            <div class="long_product_img">
                <?php $image = \App\ItemImages::where(['item_master_id' => $item->id])->first(); ?>
                <?php if(isset($image->image) && file_exists("p_img/$item->id/".$image->image)): ?>
                    <img src="<?php echo e(url('p_img').'/'.$item->id.'/'.$image->image); ?>">
                <?php else: ?>
                    <img src="<?php echo e(url('images/default.png')); ?>">
                <?php endif; ?>
                <div class="hover_center_block" id="<?php echo e($item->id); ?>"
                     onclick="getItemDetails(this);"
                     data-toggle="modal"
                     data-target="#Modal_ViewProductDetails">
                    <div class="product_hover_block">
                        <div class="mdi mdi-magnify"></div>
                    </div>
                </div>
            </div>
            <?php $prices = \App\ItemPrice::where(['item_master_id' => $item->id])->get(); ?>
            <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="long_spinner_withbtn">
                    <div class="input-group long_qty_box"><span class="long_qty_txt" id="price_<?php echo e($item->id); ?>"
                                                                data-content="<?php echo e($price->id); ?>"><?php echo e($price->unit); ?>

                            -<?php echo e($price->price); ?></span>
                        <input type="number"
                               class="form-control text-center qty_edittxt"
                               min="0"
                               max="<?php echo e($price->qty); ?>"
                               value="0" id="qty_<?php echo e($item->id); ?>">
                    </div>
                    <button class="spinner_addcardbtn btn-primary"
                            id="<?php echo e($item->id); ?>"
                            type="button" data-content="<?php echo e($price->id); ?>"
                            onclick="AddTOcart(this);">
                        <i id="<?php echo e($item->id); ?>" class="mdi mdi-basket"></i> <span
                                class="button-group_text">Add</span>
                    </button>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    
<?php endif; ?>

