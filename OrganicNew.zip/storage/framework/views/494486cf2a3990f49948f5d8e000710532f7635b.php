<?php $__env->startSection('title', 'Organic Food : Product Details'); ?>

<?php $__env->startSection('head'); ?>
    <script src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.5/jquery-ui.min.js'></script>
    <style type="text/css">
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            /* background-size: 100%;*/
            /*         width: 18px;
                     height:40px;
                     right: -1px;*/
            /* position: relative;*/
            opacity: 1;
        }

        .qty_edittxt {
            /* position: initial !important;*/
        }

        .long_qty_box {
            max-width: 200px;
        }
    </style>
    <script type="text/javascript">
        function appendimages(dis) {
            var src_no = $(dis).attr('src');
            $('#view_images').attr('src', src_no);
            $('#view_large_bg').css('background-image', 'url("' + src_no + '")');
            Initialize_ProductDetails();
        }

        function Initialize_ProductDetails() {
            var native_width = 0;
            var native_height = 0;
            $(".large").css("background", "url('" + $(".small").attr("src") + "') no-repeat");
            //Now the mousemove function
            $(".magnify").mousemove(function (e) {
                if (!native_width && !native_height) {
                    var image_object = new Image();
                    image_object.src = $(".small").attr("src");
                    native_width = image_object.width;
                    native_height = image_object.height;
                }
                else {
                    var magnify_offset = $(this).offset();
                    var mx = e.pageX - magnify_offset.left;
                    var my = e.pageY - magnify_offset.top;
                    if (mx < $(this).width() && my < $(this).height() && mx > 0 && my > 0) {
                        $(".large").fadeIn(100);
                    }
                    else {
                        $(".large").fadeOut(100);
                    }
                    if ($(".large").is(":visible")) {
                        var rx = Math.round(mx / $(".small").width() * native_width - $(".large").width() / 2) * -1;
                        var ry = Math.round(my / $(".small").height() * native_height - $(".large").height() / 2) * -1;
                        var bgp = rx + "px " + ry + "px";
                        var px = mx - $(".large").width() / 2;
                        var py = my - $(".large").height() / 2;
                        $(".large").css({left: px, top: py, backgroundPosition: bgp});
                    }
                }
            });
        }

        var fixed_leftposition;

        function checkOffFixed() {
            if ($('#product_details_containner').offset().top + $('#product_details_containner').height()
                >= $('#footer').offset().top - 30) {
                $('#product_details_containner').removeClass('position_fixed_removed');
                $('#product_details_containner').css('left', 0);
            }
            if ($(document).scrollTop() + window.innerHeight < $('#footer').offset().top) {
                $('#product_details_containner').addClass('position_fixed_removed');
                $('#product_details_containner').css('left', fixed_leftposition);
            }
        }

        $(document).ready(function () {
            Initialize_ProductDetails();
            fixed_leftposition = $('#product_details_containner').offset().left;
            if ($(document).scrollTop() < 100) {
                $('#product_details_containner').css('left', fixed_leftposition);
                $('#product_details_containner').addClass('position_fixed_removed');
            }
        });
        $(document).scroll(function () {
            checkOffFixed();
        });

        function Rating_slide() {
            var rating_position = $('#rating_product_row').offset().top;
            $('html, body').animate({scrollTop: rating_position - 95}, 1000);
        }

        function Review_slide() {
            var review_position = $('#review_product_row').offset().top;
            $('html, body').animate({scrollTop: review_position - 95}, 1000);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="product_viewblock">
        <div class="container">
            <div class="all_data_view">
                <div class="col-sm-12">
                    <div class="product_details_containner">
                        <div class="product_magnifyimages_box" id="product_details_containner">
                            <div class="magnify">
                                <div class="large" id="view_large_bg"></div>
                                <?php if(count($item_images)>0 && file_exists("p_img/$item->id/".$item_images[0]->image)): ?>
                                    <img class="small" id="view_images"
                                         src="<?php echo e(url('p_img').'/'.$item->id.'/'.$item_images[0]->image); ?>">
                                <?php else: ?>
                                    <img class="small" id="view_images" src="<?php echo e(url('images/default.png')); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="product_images_thumbbox">
                                <?php if(count($item_images)>0): ?>
                                    <?php $__currentLoopData = $item_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(file_exists("p_img/$item->id/".$image->image)): ?>
                                            <img class="product_brics_images"
                                                 src="<?php echo e(url('p_img').'/'.$item->id.'/'.$image->image); ?>"
                                                 onclick="appendimages(this);">
                                            
                                            
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <img class="small" id="view_images" src="<?php echo e(url('images/default.png')); ?>">
                                <?php endif; ?>

                                
                                
                                
                            </div>
                            <div class="availability_boxes">
                                <div class="offer_available" style="display: none">
                                    <div class="option_availability">
                                        <div class="option_txt">Option Availibity :</div>
                                        <select class="form-control rate" name="unit" value="" id="unit3">
                                            <option value="7">1 kg -
                                                Rs.20.00
                                            </option>
                                            <option value="8">500 gm -
                                                Rs.10.00
                                            </option>
                                        </select>
                                    </div>
                                    <div class="option_availability">
                                        <div class="option_txt">Qty :</div>
                                        <input type="number" min="1" max="10" class="form-control text-center"
                                               value="1">
                                    </div>
                                </div>
                                <!-- <div class="option_availability">
                                     <div class="option_txt">Option Availibity :</div>-->
                                <?php $__currentLoopData = $item_prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="long_spinner_withbtn">
                                        <div class="long_qty_box">
                                            <span class="long_qty_txt" id="price_<?php echo e($item->id); ?>"
                                                  data-content="<?php echo e($price->id); ?>"><?php echo e($price->unit); ?>

                                                - <?php echo e($price->price); ?></span>
                                            <input type="number" class="form-control text-center qty_edittxt" min="0"
                                                   value="1" max="<?php echo e($price->qty); ?>" id="qty_<?php echo e($item->id); ?>"/>
                                        </div>
                                        <button class="spinner_addcardbtn btn-primary" data-content="<?php echo e($price->id); ?>"
                                                type="button" id="<?php echo e($item->id); ?>" onclick="AddTOcart(this);"><i
                                                    class="mdi mdi-basket"></i> <span id="<?php echo e($item->id); ?>"
                                                                                      data-content="<?php echo e($price->id); ?>"
                                                                                      onclick="AddTOcart(this);"
                                                                                      class="button-group_text">Add</span>
                                        </button>
                                    </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!--</div>-->
                                <div class="product_btn_box" style="display: none;">
                                    <div class="btn btn-warning product_add_tocard" id="<?php echo e($item->id); ?>"
                                         data-content="<?php echo e($price->id); ?>" onclick="AddTOcart(this);"
                                         style="margin-right: 4%;">
                                        <i class="mdi mdi-basket"></i>Add To card
                                    </div>
                                    <a href="<?php echo e(url('checkout')); ?>" class="btn btn-success product_add_tocard"><i
                                                class="mdi mdi-cart"></i>Buy Now</a>
                                </div>
                            </div>
                        </div>
                        <div class="more_productother_details">
                            <div class="more_product_head">
                                <?php echo e($item->name); ?>

                            </div>
                            <?php
                                $five = 0;
                                $four = 0;
                                $three = 0;
                                $two = 0;
                                $one = 0;
                                $all = 0;

                            ?>
                            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if($review->star_rating == 5): ?>
                                    <?php $five += 1; $all += 1 ?>
                                <?php elseif($review->star_rating == 4): ?>
                                    <?php $four += 1; $all += 1  ?>
                                <?php elseif($review->star_rating == 3): ?>
                                    <?php $three += 1; $all += 1  ?>
                                <?php elseif($review->star_rating == 2): ?>
                                    <?php $two += 1; $all += 1  ?>
                                <?php elseif($review->star_rating == 1): ?>
                                    <?php $one += 1; $all += 1  ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="product_row">
                                <div class="rating_box" onclick="Rating_slide();">
                                    <div class="star_with_txt">
                                        <i class="mdi mdi-star"></i>0.0
                                    </div>
                                    0 Ratings
                                </div>
                                <div class="review_box" onclick="Review_slide();">
                                    <div class="star_with_txt">
                                        <i class="mdi mdi-message-reply-text"></i></div>
                                    0 Reviews
                                </div>
                            </div>
                            
                            

                            
                            
                            
                            
                            
                            
                            <div class="more_product_head product_mainhead">
                                Specifications :
                            </div>
                            <div class="option_availability">

                                <div class="option_txt"><?php echo $item->specifcation; ?></div>
                            </div>
                            

                            <div class="more_product_head product_mainhead">
                                Ingredients :
                            </div>
                            <div class="more_product_details">
                                <?php echo $item->ingredients; ?>

                            </div>
                            <div class="more_product_head product_mainhead">
                                Available Nutrients :
                            </div>
                            <div class="more_product_details">
                                <?php echo $item->nutrients; ?>

                            </div>
                            <div class="more_product_head product_mainhead">
                                Description :
                            </div>
                            <div class="more_product_details">
                                <?php echo $item->description; ?>

                            </div>
                            <div class="more_product_head product_mainhead">
                                Usage :
                            </div>
                            <div class="more_product_details">
                                <?php echo $item->usage; ?>

                            </div>
                            <div class="more_product_head product_mainhead" id="rating_product_row">
                                Ratings :
                            </div>

                            <div class="product_row">
                                <div class="well well-sm">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-6 text-center">
                                            <h1 class="rating-num">
                                                <?php echo e($all/5); ?></h1>
                                            
                                            <div class="rating">
                                                <span class="glyphicon glyphicon-star"></span><span
                                                        class="glyphicon glyphicon-star">
                            </span><span class="glyphicon glyphicon-star"></span><span class="glyphicon glyphicon-star">
                            </span><span class="glyphicon glyphicon-star-empty"></span>
                                            </div>
                                            <div>
                                                <span class="glyphicon glyphicon-user"></span><?php echo e(count($reviews)); ?> total
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-md-6">

                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            
                                            <div class="row rating-desc">
                                                <div class="col-xs-3 col-md-3 text-right">
                                                    <span class="glyphicon glyphicon-star"></span>5
                                                </div>
                                                <div class="col-xs-8 col-md-9">
                                                    <div class="progress progress-striped">
                                                        <div class="progress-bar progress-bar-success"
                                                             role="progressbar"
                                                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"
                                                             style="width: <?php echo e(round($five *100 / count($reviews),2)); ?>%">
                                                            <span class="sr-only"><?php echo e(round($five *100 / count($reviews),2)); ?>%</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end 5 -->
                                                <div class="col-xs-3 col-md-3 text-right">
                                                    <span class="glyphicon glyphicon-star"></span>4
                                                </div>
                                                <div class="col-xs-8 col-md-9">
                                                    <div class="progress">
                                                        <div class="progress-bar progress-bar-success"
                                                             role="progressbar"
                                                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"
                                                             style="width: <?php echo e(round($four *100 / count($reviews),2)); ?>%">
                                                            <span class="sr-only"><?php echo e(round($four *100 / count($reviews),2)); ?>%</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end 4 -->
                                                <div class="col-xs-3 col-md-3 text-right">
                                                    <span class="glyphicon glyphicon-star"></span>3
                                                </div>
                                                <div class="col-xs-8 col-md-9">
                                                    <div class="progress">
                                                        <div class="progress-bar progress-bar-info" role="progressbar"
                                                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"
                                                             style="width: <?php echo e(round($three *100 / count($reviews),2)); ?>%">
                                                            <span class="sr-only"><?php echo e(round($three *100 / count($reviews),2)); ?>%</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end 3 -->
                                                <div class="col-xs-3 col-md-3 text-right">
                                                    <span class="glyphicon glyphicon-star"></span>2
                                                </div>
                                                <div class="col-xs-8 col-md-9">
                                                    <div class="progress">
                                                        <div class="progress-bar progress-bar-warning"
                                                             role="progressbar"
                                                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"
                                                             style="width: <?php echo e(round($two *100 / count($reviews),2)); ?>%">
                                                            <span class="sr-only"><?php echo e(round($two *100 / count($reviews),2)); ?>%</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end 2 -->
                                                <div class="col-xs-3 col-md-3 text-right">
                                                    <span class="glyphicon glyphicon-star"></span>1
                                                </div>
                                                <div class="col-xs-8 col-md-9">
                                                    <div class="progress">
                                                        <div class="progress-bar progress-bar-danger" role="progressbar"
                                                             aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"
                                                             style="width:<?php echo e(round($one *100 / count($reviews),2)); ?>%">
                                                            <span class="sr-only"><?php echo e(round($one *100 / count($reviews),2)); ?>%</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end 1 -->
                                            </div>
                                            <!-- end row -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="more_product_head product_mainhead" id="review_product_row">
                                Reviews :
                            </div>
                            <div class="product_row">
                                <div class="review-block">
                                    <?php if(count($reviews)>0): ?>
                                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <?php if($review->user->profile_img != 'images/Male_default.png' && file_exists($review->user->profile_img)): ?>
                                                        <img src="<?php echo e(url('u_img').'/'.$review->user_id.'/'.$review->user->profile_img); ?>"/>
                                                    <?php else: ?>
                                                        <img src="<?php echo e(url('images/Male_default.png')); ?>"
                                                             class="img-rounded"/>
                                                    <?php endif; ?>
                                                    <div class="review-block-name"><a
                                                                href="#"><?php echo e($review->user->name); ?></a></div>
                                                    <div class="review-block-date"><?php echo e(date_format(date_create($review->created_at), "d-M-Y")); ?></div>
                                                </div>
                                                <div class="col-sm-9">
                                                    <div class="review-block-rate">
                                                        <?php for($i = 1; $i<=5; $i++): ?>
                                                            <?php if($i <= $review->star_rating): ?>
                                                                <button type="button" class="btn btn-success btn-xs"
                                                                        aria-label="Left Align">
                                                        <span class="glyphicon glyphicon-star"
                                                              aria-hidden="true"></span>
                                                                </button>
                                                            <?php else: ?>
                                                                <button type="button"
                                                                        class="btn btn-default btn-grey btn-xs"
                                                                        aria-label="Left Align">
                                                        <span class="glyphicon glyphicon-star"
                                                              aria-hidden="true"></span>
                                                                </button>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </div>
                                                    <div class="review-block-title">
                                                        <?php echo e($review->review); ?>

                                                    </div>
                                                </div>
                                            </div>
                                            <hr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <div class="row">
                                            <span>No Review Available</span>
                                        </div>
                                    <?php endif; ?>

                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('web.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script>
        function AddTOcart(dis) {
            var itemid = $(dis).attr('id');
            var rateid = $(dis).attr('data-content');
            var qty = $('#qty_' + itemid).val();
            var carturl = "<?php echo e(url('addtocart')); ?>";
            $.ajax({
                type: "get",
                contentType: "application/json; charset=utf-8",
                url: carturl,
                data: {itemid: itemid, rateid: rateid, quantity: qty},
                success: function (data) {
                    $("#cartload").html(data);
//                    ShowSuccessPopupMsg('Product has been added to cart');
                },
                error: function (xhr, status, error) {
                    $("#cartload").html(xhr.responseText);
//                    alert('Technical Error Occured!');
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.e_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>