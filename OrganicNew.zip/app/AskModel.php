<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AskModel extends Model
{
    protected $table = 'ask';
    public $timestamps = false;
}
