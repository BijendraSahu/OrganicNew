<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderDescription extends Model
{
    protected $table = 'order_description';
    public $timestamps = false;
}
