<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class itemMetamodel extends Model
{
    protected $table = 'item_meta';
    public $timestamps = false;
}
